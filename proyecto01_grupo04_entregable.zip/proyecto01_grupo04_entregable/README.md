# CE4302 - Arquitectura de Computadores 2
Primer proyecto: Coherence modeling and evaluation

## Target Architecture
- windows x86

## Dependencias
- log4net
- Stateless
- Microsoft.Extensions.Logging
- HIC.System.Windows.Forms.DataVisualization

## Ejecución 
- bin/Release/net6.0-windows/Proyecto1.exe
No es necesaria ninguna compilación ni instalación adicional.
